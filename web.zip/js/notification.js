/*本示例是调用系统推送通知功能*/
if (!window.Notification) {
    window.toast.Maketoast("浏览器不支持通知！");
    
}
console.log(window.Notification.permission);
if (window.Notification.permission != 'granted') {
    Notification.requestPermission(function (status) {
        //status是授权状态，如果用户允许显示桌面通知，则status为'granted'
        console.log('status: ' + status);
        //permission只读属性:
        //  default 用户没有接收或拒绝授权 不能显示通知
        //  granted 用户接受授权 允许显示通知
        //  denied  用户拒绝授权 不允许显示通知
        var permission = Notification.permission;
        console.log('permission: ' + permission);
    });
}
//显示通知
var notify_title = "关于位置显示！"; //标题
var notify_body = "GPS相对于IP要准确一些，手机上访问可获得更精确位置。"; //内容
var notify_icon = "https://webmap0.bdimg.com/image/api/marker_red.png"; //图标
var notify_target="/index.html"; //点击打开页面，不需要设置为""
var notify ;
show_notifcation(notify_title, notify_icon, notify_body);
//系统推送通知函数
function show_notifcation(notify_title, notify_icon, notify_body) {
    //创建推送通知
    notify = new Notification(notify_title, { "icon": notify_icon, "body": notify_body });
    //创建通知事件onshow显示通知事件，onclick点击通知事件...
    notify.onshow = function () { console.log("显示通知"); setTimeout(function () { notify.close() }, 5000); };
    notify.onclick = function () { if (notify_target != "") { alert(notify_target); window.open(notify_target);} notify.close(); };
    notify.onclose = function () { console.log("通知关闭"); };
    notify.onerror = function () { console.log('产生错误'); };
}
