/*本例通过网络或GPS定位显示位置

*/
//判断系统是否支持网络或GPS定位显示位置
function getLocation() {
    var xxx = document.getElementById("pic");
    if (navigator.geolocation) { //判断navigator.geolocation如真代表支持定位
        /*navigator.geolocation.getCurrentPosition
        navigator.geolocation.position.coords.latitude纬度
        navigator.geolocation.position.coords.longitude经度*/
        xxx.innerHTML = "正在定位....";
        var options = {
            enableHighAccuracy: true, //高精度定位参数
            maximumAge : 1000 //最长定位间隔
        }
        showmap(); //调用地图div显示
        //navigator.geolocation.watchPosition(showPosition, showError,options);//调用持续定位，watchPosition成功调用showPosition，失败调用showError
        navigator.geolocation.getCurrentPosition(showPosition, showError,options);//调用定位，getCurrentPosition成功调用showPosition，失败调用showError
    }
    else { xxx.innerHTML = "浏览器不支持Geolocation"; }
}
//定位成功
function showPosition(position) {//position是成功后返回的坐标信息参数navigator.geolocation.position类型
    var xxx = document.getElementById("pic");
    xxx.innerHTML = "纬度: " + position.coords.latitude + "<br />经度: " + position.coords.longitude;
    // + "<br />海拔: " + position.coords.altitude + "<br />速度: "    + position.coords.speed + "<br />方向: " + position.coords.heading;
    
    x = position.coords.longitude; //纬度
    y = position.coords.latitude; //经度
    ggPoint = new BMapGL.Point(x, y) //转换为坐标类型
    bm.centerAndZoom(ggPoint, 16); //设置到地图上
    
    //定位后加载地图调用坐标转换
    var pointArr = [];
    pointArr.push(ggPoint);
    convertor.translate(pointArr, COORDINATES_WGS84, COORDINATES_BD09, translateCallback);

}

//定位失败
function showError(error) {
    var xxx = document.getElementById("pic");
    switch (error.code) {
        case error.PERMISSION_DENIED:
            xxx.innerHTML = "没有位置权限."
            break;
        case error.POSITION_UNAVAILABLE:
            xxx.innerHTML = "无法获取位置."
            break;
        case error.TIMEOUT:
            xxx.innerHTML = "获取位置超时."
            break;
        case error.UNKNOWN_ERROR:
            xxx.innerHTML = "未知错误."
            break;
    }
    notify_title = "GPS定位失败";
    notify_body = xxx.innerHTML;
    notify_icon = "https://webmap0.bdimg.com/image/api/marker_red.png";
    notify_target="";
    show_notifcation(notify_title, notify_icon, notify_body);
}
