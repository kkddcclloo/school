/*本示例调用百度地图webgl操作
<script src="https://api.map.baidu.com/getscript?type=webgl&v=1.0&ak=百度开发key"></script>
*/
var x = 110.867821;//地图初始化经度坐标
var y = 35.297291; //地图初始化纬度坐标

var ggPoint = new BMapGL.Point(x, y);//转换为坐标类型
var mapheight = 0;//地图高度，配合closemap()动画关闭div使用
//地图初始化
var bm = new BMapGL.Map("allmap");//创建BMapGL对象，allmap是地图容器的div id

bm.centerAndZoom(ggPoint, 11);  //设置地图中心坐标和缩放级别
bm.enableScrollWheelZoom(true);     //开启鼠标滚轮缩放
var scaleCtrl = new BMapGL.ScaleControl();  // 添加比例尺控件
bm.addControl(scaleCtrl);
var zoomCtrl = new BMapGL.ZoomControl();  // 添加缩放控件
bm.addControl(zoomCtrl);

var convertor = new BMapGL.Convertor();
/*坐标转换对象，从GPS转到专用坐标
convertor.translate(pointArr, 被转换坐标如COORDINATES_WGS84, 转换坐标如COORDINATES_BD09, translateCallback)
pointArr转换的坐标，类型为数组
    var pointArr = [];
    pointArr.push(ggPoint); //将坐标类型数据推入数组
    被转换坐标如COORDINATES_WGS84, 转换坐标如COORDINATES_BD09见下面常量说明
    translateCallback转换函数
**
 * 坐标常量说明：
 * COORDINATES_WGS84 = 1, WGS84坐标，常见的GPS
 * COORDINATES_WGS84_MC = 2, WGS84的平面墨卡托坐标
 * COORDINATES_GCJ02 = 3，GCJ02坐标
 * COORDINATES_GCJ02_MC = 4, GCJ02的平面墨卡托坐标
 * COORDINATES_BD09 = 5, 百度bd09经纬度坐标
 * COORDINATES_BD09_MC = 6，百度bd09墨卡托坐标
 * COORDINATES_MAPBAR = 7，mapbar地图坐标
 * COORDINATES_51 = 8，51地图坐标
*/

//添加gps marker和label
var markergg = new BMapGL.Marker(ggPoint);
bm.addOverlay(markergg); //添加地图标识点 marker

//坐标转换完之后的回调函数
translateCallback = function (data) {
    if (data.status === 0) {
        var marker = new BMapGL.Marker(data.points[0]);
        bm.addOverlay(marker);
        var label = new BMapGL.Label("转换后的百度坐标", { offset: new BMapGL.Size(10, 10) });
        var gc = new BMapGL.Geocoder();
        gc.getLocation(data.points[0], function (rs) {
            var addComp = rs.addressComponents;
            var poi = rs.surroundingPois;//信息点集合
            var poititle = poi[0].title; //第一个信息点名称
            address = rs.address;//具体地址，如果想分省市区街道用下面这条
            //address = addComp.province + addComp.city + addComp.district + addComp.street + addComp.streetNumber;
            /*label = new BMapGL.Label(address, { offset: new BMapGL.Size(20, -90) });
            label.setStyle({
                fontSize: '26px'
            });
            marker.setLabel(label); 设置普通标记，但下面是用信息提示窗口显示，所以注释掉*/

            //使用信息窗口提示
            var opts = {
                width: 300,     // 信息窗口宽度
                height: 80,     // 信息窗口高度
                title: poititle + "附近", // 信息窗口标题
                message: "GPS"
            }
            var infoWindow = new BMapGL.InfoWindow('<span style="font-size:20px;color:darkgreen;">' + address + '</span>', opts);  // 创建信息窗口对象 
            bm.openInfoWindow(infoWindow, data.points[0]); //开启信息窗口
            marker.addEventListener("click", function () {
                bm.openInfoWindow(infoWindow, data.points[0]); //开启信息窗口
            });
            //调用推送通知
            notify_title = "GPS定位结果";
            notify_body = "坐标:\n纬度" + data.points[0].lat + "\n经度" + data.points[0].lng + "\n名称:" + poititle + "\n位于:" + address;
            notify_icon = "https://webmap0.bdimg.com/image/api/marker_red.png";
            notify_target = "";
            if (data.points[0].lng != 110.87972324178625) {
                try {
                    window.toast.Maketoast("位于" + address + poititle + "附近");//移动端toast提示
                } catch (e) {
                    console.log("错误：" + e);
                }

                show_notifcation(notify_title, notify_icon, notify_body);
            }

        });
        // marker.setLabel(label); //添加百度label
        bm.centerAndZoom(data.points[0], 16);
        bm.addControl(scaleCtrl);
    }
}

//第一次加载地图调用坐标转换
setTimeout(function () {
    var pointArr = [];
    pointArr.push(ggPoint);
    convertor.translate(pointArr, COORDINATES_WGS84, COORDINATES_BD09, translateCallback)
}, 1000);



//显示地图div
function showmap() {
    var dismap = document.getElementById("allmap").style;
    dismap.display = "";
    if (mapheight < 100) {
        mapheight = 100;
        dismap.height = mapheight * 0.8 + "%";
        dismap.width = mapheight + "%";

    }
    else {
        document.getElementById("img").innerHTML = "关闭地图";

    }
}
//隐藏地图div
function closemap() {
    var dismap = document.getElementById("allmap").style;
    if (mapheight > 0) {
        mapheight -= 1;
        dismap.height = mapheight * 0.8 + "%";
        dismap.width = mapheight + "%";
        document.getElementById("img").innerHTML = mapheight;
        setTimeout("closemap()", 10);
    }
    else {
        document.getElementById("img").innerHTML = "关闭地图";
        dismap.display = "none";
    }
}