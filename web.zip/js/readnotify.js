/*本示例是利用fetch读取json文件内容，并推送系统通知*/
function getJson() {
    fetch('https://rawgithub.pages.dev/kkddcclloo/padavan-4.4/main/test/test.json')
        .then(function (response) {
            return response.json();
        })
        .then(function (data) {

            var pageData = data;
            var needpush = pageData[0].push; //是否需要推送通知，注意这个needpush是局部变量，为"1"代表推送
            notify_title = pageData[0].title;
            notify_body = pageData[0].content;
            notify_icon = pageData[0].icon;
            notify_target = pageData[0].target;
            if (needpush == "1") {
                show_notifcation(notify_title, notify_icon, notify_body);
            }
        });
    setTimeout("getTxt()", 300000);//5分钟自动刷新读取通知数据
}
getJson();



