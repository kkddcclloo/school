/*本示例调用sohu的通过IP显示位置功能
<script src="https://pv.sohu.com/cityjson?ie=utf-8"></script>
*/
function showmyip() {
    //显示IP和位置
    document.getElementById("showip").innerHTML = returnCitySN["cip"] + ',' + returnCitySN["cname"];
    //调用系统推送通知
    notify_title = "IP定位结果";
    notify_body = returnCitySN["cip"] + ',' + returnCitySN["cname"];
    notify_icon = "https://webmap0.bdimg.com/image/api/marker_red.png";
    notify_target ="";
    show_notifcation(notify_title, notify_icon, notify_body);
}